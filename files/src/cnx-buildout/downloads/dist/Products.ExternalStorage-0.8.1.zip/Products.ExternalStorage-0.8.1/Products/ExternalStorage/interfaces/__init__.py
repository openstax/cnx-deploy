"""ExternalStorage interfaces package"""

from externalstorage import IExternalStorage
