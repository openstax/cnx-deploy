""" BeeBase - A suite of building parts for databases.

    Copyright (c) 1998-2000, Marc-Andre Lemburg; mailto:mal@lemburg.com
    Copyright (c) 2000-2012, eGenix.com Software GmbH; mailto:info@egenix.com
    See the documentation for further information on copyrights,
    or contact the author. All Rights Reserved.

    HTML-Logo:

    <FONT COLOR="#FF3333"><SUP><B>Bee</B></SUP></FONT><B>Base</B></FONT>

"""#"

# Import version from C extension
from mxBeeBase import __version__

